# $ make list-projects
#
# Sample projects: template biorobots-sample cancer-biorobots-sample cancer-immune-sample"
#                 celltypes3-sample heterogeneity-sample pred-prey-farmer virus-macrophage-sample worm-sample"
#
# Sample intracellular projects: ode-energy-sample physiboss-cell-lines-sample cancer-metabolism-sample"

make
make reset
make biorobots-sample 
make
make reset
make cancer-biorobots-sample 
make
make reset
make heterogeneity-sample
make
make reset
make ode-energy-sample
make
make reset
make physiboss-cell-lines-sample 
make
make reset
make cancer-metabolism-sample
make
make reset
make biorobots-sample 
make
